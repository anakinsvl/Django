from django import forms  
from myapp.models import Student  
#this file is manually created for forms attribute  
class StudentForm(forms.ModelForm):  
    class Meta:  
        model = Student  
        fields = ['name', 'contact', 'email']
        widgets = { 'name': forms.TextInput(attrs={ 'class': 'form-control' }),
            'email': forms.EmailInput(attrs={ 'class': 'form-control' }),
            'contact': forms.TextInput(attrs={ 'class': 'form-control' }),
      }
