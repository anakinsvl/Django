from django.db import models
 
# Create your models here.
#make sure to use migrations and migrate everytime a model is added or removed.
class Student(models.Model):  
    name = models.CharField(max_length=100)  
    email = models.EmailField()  
    contact = models.CharField(max_length=15)
   
    class Meta:  
        db_table = "tblemployee"